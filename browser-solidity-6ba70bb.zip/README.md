# Automatic build
Built website from `6ba70bb`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `browser-solidity-6ba70bb.zip`.
